package usuarios;

public interface RegistrarVenta {

    /**
     * @param id del producto que se vende
     * @param cantidadVendida cantidad que se vende
     */
    public void registrarVenta(int id, int cantidadVendida);

}
